// empty, not needed

chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed.");
});
